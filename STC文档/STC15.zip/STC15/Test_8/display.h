#ifndef _DISPLAY_H_
#define _DISPLAY_H_

#include"ds1302.h"

void display1(uchar yi);
void display2(uchar er);
void display3(uchar san);
void display4(uchar si);
void display5(uchar wu);
void display6(uchar liu);
void display7(uchar qi);
void display8(uchar ba);

#endif