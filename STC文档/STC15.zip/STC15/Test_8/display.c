//#include"ds1302.h"

#include"key.h"

#include"display.h"

//uchar code tab[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90,0XBF,0XFF};

//uchar code w_tab[] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};	 //��λ�����λѡ
uchar yi, er, san, si, wu, liu, qi, ba;


//�������ʱ����
void delayms(int ms)
{
	int i,j;
	for(i=ms;i>0;i--)
		for(j=845;j>0;j--);
}


//�������ʾ
void display1(uchar yi)
{
		P2=0XC0;//��λѡ573   U8
		P0=0X01;//ѡ���һ�������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[yi];
				delayms(1000);
				P0 = ~tab[yi];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[yi];
		delayms(1);
}

void display2(uchar er)
{		
		P2=0XC0;//��λѡ573   U8
		P0=0X02;//ѡ��ڶ��������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[er];
				delayms(1000);
				P0 = ~tab[er];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[er];
		delayms(1);
}	

void display3(uchar san)
{
		P2=0XC0;//��λѡ573   U8
		P0=0X04;//ѡ������������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[san];
				delayms(1000);
				P0 = ~tab[san];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[san];
		delayms(1);
}

void display4(uchar si)
{		
		P2=0XC0;//��λѡ573   U8
		P0=0X08;//ѡ����ĸ������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[si];
				delayms(1000);
				P0 = ~tab[si];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[si];
		delayms(1);
}

void display5(uchar wu)
{
		P2=0XC0;//��λѡ573   U8
		P0=0X10;//ѡ�����������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[wu];
				delayms(1000);
				P0 = ~tab[wu];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[wu];
		delayms(1);
}

void display6(uchar liu)
{	
		P2=0XC0;//��λѡ573   U8
		P0=0X20;//ѡ������������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[liu];
				delayms(1000);
				P0 = ~tab[liu];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[liu];
		delayms(1);
}


void display7(uchar qi)
{
		P2=0XC0;//��λѡ573   U8
		P0=0X40;//ѡ����߸������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[qi];
				delayms(1000);
				P0 = ~tab[qi];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[qi];
		delayms(1);
}

void display8(uchar ba)
{		
		P2=0XC0;//��λѡ573   U8
		P0=0X80;//ѡ��ڰ˸������
		P2=0XFF;//�򿪶�ѡ573   U7
		if(keyflag == 0)
		{
			while(!keyflag)
			{
				 P0 = tab[ba];
				delayms(1000);
				P0 = ~tab[ba];
				delayms(1000);
			}
				
		}
			 
		else
			P0=tab[ba];
		delayms(1);
}