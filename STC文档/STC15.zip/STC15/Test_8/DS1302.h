#ifndef _DS1302_H_		   //DS1302����
#define _DS1302_H_

#include<stc15f2k60s2.h>

#include<intrins.h>

#define uchar unsigned char 
#define uint unsigned int

sbit CE=P1^3;
sbit IO=P2^3;
sbit SCLK=P1^7;

extern uchar shijian[7];//���ʱ��	//����ȫ�ֱ��������ܳ�ʼ��

extern uchar code tab[];

extern uchar code w_tab[];

extern uchar yi,er,san,si,wu ,liu,qi,ba;
	
void writebyte(uchar dat);
void write(uchar add,uchar dat);
void dsinit();
uchar read(uchar add);
uchar readbyte();
void readtime();


#endif