#include"adc_PCF8591.h"

void  init_pcf8591(void)
{
	iic_start();
	iic_sendbyte(0x90);
	iic_waitack();
	iic_sendbyte(CHANNEL_3);
	iic_waitack();
	iic_stop();
	delay(10);
}

//���߿�ʼ
void iic_start(void)
{
	SDA = 1;
	_nop_();
	SCL = 1;
	somenop();
	SDA = 0;
	somenop();
	SCL = 0;
}
//���߽���ռ��
void  iic_stop(void)
{
	SDA = 0;
	_nop_();
	SCL = 1;
	somenop();
	SDA = 1;

}
//�����ʴ�
void iic_ack(bit ackbit)
{
	if(ackbit)
		SDA = 0;
	else
		SDA = 1;
	 somenop();
	 SCL = 1;
	 somenop();
	 SCL = 0;
	 SDA = 1;
	 somenop();

}
  //�ȴ���Ӧ
bit  iic_waitack(void)
{
	 SDA = 1;
	 somenop();
	 SCL = 0;
	 somenop();
	 if(SDA)
	 {
	 	SCL = 0;
		iic_stop();
		return 0;
	 }
	 else
	 {
	 	 SCL = 0;
		 return 1;
	 }

}
//ͨ�����߷����ֽ�
void  iic_sendbyte(uchar byt)
{
	uchar i;
	for(i = 0; i<8; i++)
	{
		if(byt&0x80)
			SDA = 1;
		else
			SDA = 0;
		somenop();
		SCL = 1;
		byt <<= 1;
		somenop();
		SCL = 0;	
	}
}
 //ͨ�����߷����ֽ�
uchar iic_recbyte(void)
{
	 uchar da;
	  uchar i;
	  for(i = 0; i<8; i++)
	  {
	  	 SCL = 1;
		 somenop();
		 da <<= 1;
		 if(SDA)
		 	da |= 0x01;
		SCL = 0;
		 somenop();
	  }
	  return da;
}
/*
void delay(uchar t)
{
	uchar i;
	while(t--)
	{
		for(i = 0; i<112; i++);

	}
}
*/

//��ADC����
uchar adc_pcf8591(void)
{
	 uchar temp;

	 iic_start();
	 iic_sendbyte(0x91);
	 iic_waitack();
	 temp = iic_recbyte();
	 iic_ack(0);
	 iic_stop();

	 return temp;

}