#ifndef _KEY_H_
#define _KEY_H_

extern char key_adcnum;
extern bit keyflag;
extern bit ad_keyflag;
void key_scan(void);

#endif