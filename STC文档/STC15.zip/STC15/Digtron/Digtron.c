/*
**CT107D�������������ʾ
**�����Ϊ������
*/

#include"stc15f2k60s2.h"
#include<intrins.h>
#define uchar unsigned char
#define Y7C 0xe0		  //��ѡ
#define Y6C 0xc0				//λѡ
#define Y5C 0xa0;
uchar code table[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80, 0x90, 0xbf};	 //0~9
uchar n, m, i = 0;
sbit BUZZ = P0^6;
/////////////////////////////////////////////////
void Delay500ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 22;
	j = 3;
	k = 227;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}
///////////////////////////////////////////////
void main(void)
 {

 	AUXR = 0xc0;	   //���⹦�ܼĴ������ö�ʱ��0,1Ϊ1Tʱ���ٶ�,�رն�ʱ��2
 	TMOD = 0;		  //��ʱ��1,0������ʽ0
	TL0 = 65536 - 45872;
	TH0 = (65536 - 45872) >> 8;
	TL1 = 65536 - 45872;
	TH1 = (65536 - 45872) >> 8;
	EA = 1;
	ET0 = 1;
	ET1 = 1;
	TF0 = 0;
	//TF1 = 0;
	TR0 = 1;
	TR1 = 1;
	P2 &= 0x1f;
	P2 |= Y5C;
	//P0 = 0xbf;
	P0 = 0x00; 
	P2 &= 0x1f;
	P2 |= Y6C;
	P0 = 0x80;
	P2 &= 0x1f;
	P2 |= Y7C;
	while(1)
	{
		if(n == 250)
			{	
				if(i < 10)
				{
					n = 0;
					P0 = table[i++];
					
				}else
				{
					i = 0;
				}
		 	}
		if(m == 300)
	 {
	 	m = 0;
		P0 = 0xc0;
		
	//	BUZZ = ~BUZZ;
		//Delay500ms();
	 }
	}
 }
/////////////////////////////////////////////////////
void T0_time() interrupt 1
{
	n++;
	
}
/////////////////////////////////////////////////////

void T1_time() interrupt 3
{
	
	 m++;
	 
	 
}	