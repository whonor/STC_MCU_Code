#include<reg52.h>

#define uchar unsigned char

#define uint unsigned int

#define Y5C 0xa0

#define Y6C 0xc0

#define Y7C 0xe0

sbit DQ=P1^4;

uchar code table[]={0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80, 0x90}; //�������������� 0-9

uchar code table1[]={0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10};//��С�����0-9��-

void delay(uint t);

void init_ds18b20();

void write_byte(uchar dat);

uchar read_byte();

uchar readtemperature();

void display();

void delay_1ms(uint z);

uchar temp,ge,shi;

void main()

{
P2 &= 0x1f;
P2 |= Y5C;
P0 = 0x00; 

while(1)

{

temp=readtemperature();

display();

}

}

void delay_1ms(uint z)

{

uchar x,y;

for(x=z;x>0;x--)

for(y=110;y>0;y--);

}

void delay(uint t)

{

while(t--);

}

void init_ds18b20()

{

uchar n;

DQ=1;

delay(8);	//11.0592MHz Լ 97us

DQ=0;

delay(80); // 11.0592MHz Լ 800us 12MHz Լ600um

DQ=1;

delay(8);

n=DQ;

delay(4);

}

void write_byte(uchar dat)

{

uchar i;

for(i=0;i<8;i++)

{

DQ=0;

DQ=dat&0x01;	//�����λ��ʼд

delay(4);

DQ=1;

dat>>=1;

}

delay(4);

}

uchar read_byte()

{

uchar i,value;

for(i=0;i<8;i++)	//�����λ��ʼ��

{

DQ=0;

value>>=1;

DQ=1;

if(DQ)

value|=0x80;

delay(4);

}

return value;

}

uchar readtemperature()

{

uchar a,b,c,dian;

init_ds18b20();

write_byte(0xcc);

write_byte(0x44);

delay(300);

init_ds18b20();

write_byte(0xcc);

write_byte(0xbe);

a=read_byte();

c=a;

c=c&0x0f;

dian=c%10;

P2 |= Y7C;

P0=table[dian];

P2 &= 0x1f;

P0=0xff;

P2 |= Y6C;

P0=0xf7;

P2 &= 0x1f;

delay_1ms(5);

b=read_byte();

if(b>0xf0)

{

P2 |= Y7C;

P0=table[10];

P2 &= 0x1f;

P0=0xff;

P2 |= Y6C;

P0=0xfe;

P2 &= 0x1f;

delay_1ms(5);

}

b<<=4;

b+=(a&0xf0)>>4;

return b;

}

void display()

{

shi=temp/10;

ge=temp%10;

P2 |= Y7C;

P0=table[shi];

P2 &= 0x1f;

P0=0xff;

P2 |= Y6C;

P0=0xfd;

P2 &= 0x1f;

delay_1ms(5);

P2 |= Y7C;

P0=table1[ge];

P2 &= 0x1f;

P0=0xff;

P2 |= Y6C;

P0=0xfb;

P2 &= 0x1f;

delay_1ms(5);

}