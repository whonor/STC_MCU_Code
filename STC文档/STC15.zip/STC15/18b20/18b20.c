//#include "stc15f2k60s2.h"
#include<reg52.h>
#define rst573 P2&=0x1f 
#define ledY4C P2|=0x80 
#define beeY5C P2|=0xa0 
#define smgY6C P2|=0xc0 
#define smgY7C P2|=0xe0 

sbit ww=P1^4;//DS18B20 1wire���� 
sbit c1302=P1^7;//SPIʱ��  
sbit d1302=P2^3;//SPI����  
sbit s1302=P1^3;//SPIʹ�� ����Ч �͸�λ 

unsigned char table[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};


void delay(unsigned int us) 
{   
	unsigned char i;
	while(us--)
	{
		for(i = 0; i < 8; i++);
	}  
}

void delay6us(unsigned char us) 
{   
	while(us--);  
}

void delaynms(unsigned int ms) 
{  
	unsigned int x,y;  
	for(x=ms;x;x--)   
		for(y=110;y;y--);  
}

void init107() 
{  
	rst573;  
	ledY4C;	
	//P36=0;  //led  	
	P0=0xff;  
	  
	rst573;  //bee  
	beeY5C;
	P0 = 0;  
	  
	rst573;  //smg  
	P0=0xff;   
	smgY6C;
	rst573;
}

void rst18B20() 
{  
	ww=1;   
	delay(100);  
	ww=0;   
	delay(750);
	ww = 1; 
	 
}

void write18B20(unsigned char temp) 
{  
	unsigned char i;  
	for(i=8;i > 0;i--)  
	{   
		ww=0;   
		temp>>=1;   
		ww=CY;    
		delay6us(5);      
		ww=1;// 
	} 
}

unsigned char read18B20() 
{  
	unsigned char i,temp;  
	for(i=8;i > 0;i--)  
	{   
		ww=0;   
		temp>>=1;    
		ww=1;			//
		if(ww)   
		temp|=0x80;    
		delay6us(5);   
	}   
	return temp;  
}

unsigned int temperature() 
{  
	unsigned char temp1,temp2, temp0;  
	unsigned int temp;  
	rst18B20();   
	write18B20(0xcc);   		 //������ROMָ��,CCH
	write18B20(0x44);
	delay(200);							//д�¶�ת��ָ��,44H
	rst18B20();   
	write18B20(0xcc);  
	write18B20(0xbe);     						 //���ݴ��������ڲ�RAM��9�ֽ��¶�����, BEH
	temp1=read18B20();//��8λ  
	temp2=read18B20();//��8λ   
	temp=temp2;  
	temp<<=8;  
	temp+=temp1;    
	temp=(unsigned int)(temp*0.0625);			//�¶��ڼĴ�����λ12λ���ֱ���Ϊ0.0625
	temp0 = temp * 10 +0.5;							   //����10��ʾС����ֻȡһλ����0.5����������
	temp0 += 0.05;  
	return temp;
}
/**************************************************************
* DS1302��������
****************************************************************/
void write1302(unsigned char addr,unsigned char dat) 
{  
	unsigned char i;  
	s1302=0;  
	c1302=0;  
	s1302=1;  
	for(i=8;i > 0;i--)  
	{   
		addr>>=1;   
		d1302=CY;    
		c1302=0;    
		c1302=1;  
	}
	for(i=8;i > 0;i--)  
	{   
		dat>>=1;   
		d1302=CY;   
		c1302=0;   
		c1302=1;   
	}
	s1302 = 0;
}

unsigned char read1302(unsigned char addr) 
{  
	unsigned char i,temp;  
	s1302=0;  
	c1302=0;   
	s1302=1;
	for(i=8;i > 0;i--)  
	{   
		addr>>=1;   
		d1302=CY;   
		c1302=0;   
		c1302=1;   
	}
	for(i=8;i > 0;i--)  
	{   
		temp>>=1;   
		c1302=1;   
		c1302=0;   
		if(d1302)    temp|=0x80;  
	}
	s1302 = 0;
	return temp;
}


void init1302() 
{  	
	write1302(0x8e,0x00);  
	write1302(0x8c,0x11);//��  
	write1302(0x8a,0x00);//��  
	write1302(0x88,0x10);//��  
	write1302(0x86,0x15);//��  
	write1302(0x84,0x15);//ʱ  
	write1302(0x82,0x04);//��  
	write1302(0x80,0x00);//��  
	write1302(0x8e,0x80);  
}

void givetime(unsigned char *p) 
{  
	unsigned char i;   
	unsigned char pp[]={0x8d,0x8b,0x89,0x87,0x85,0x83,0x81};   
	for(i=0;i<7;i++)  
	{   
		p[i]=read1302(pp[i]);   
		write1302(0x00,0x00);   
	}  
}

void smg(unsigned char aa,unsigned char bb,unsigned char cc) 
{  	
	rst573;					 //��1λ
	smgY6C; 
	P0=0x80;
	rst573; 
	smgY7C;
	P0=table[cc];  	  
	delaynms(5);

	rst573;					  //��2λ
	smgY6C;
	P0=0x40;  
	rst573; 
	smgY7C;  
	P0=table[bb];  	   
	delaynms(5);
	
	rst573;					   //��3λ
	smgY6C;
	P0=0x20;  
	rst573;  
	smgY7C;   
	P0=table[aa];  	  
	delaynms(5);
/*	
	rst573;					   //��4λ
	smgY6C;  
	P0=0x10;   
	rst573;  
	smgY7C;  
	P0=table[aa];    
	delaynms(5);  
	*/
}

/*void main()//���1302 
{  
	unsigned char temp[7];  
	unsigned char tt;  
	unsigned char i;  
	init107();  
	init1302();   
	givetime(temp);  
	i=3;//�ֶ����ڣ�����ʾ��һ�����ݣ�������iΪ�����ֱ�������غ󣬿���ʾ�Ƿ���ȷ��  
	tt=temp[i]/16;   
	temp[i]=temp[i]%16;   
	temp[i]=tt*10+temp[i];
	while(1)   
	smg(temp[i]/1000,temp[i]%1000/100,temp[i]%100/10,temp[i]%10);
}
*/
void main()//���18B20 
{  
	unsigned int temp;  
	init107();  
	while(1)  
	{   
		temp=temperature();    
		smg(temp/100, temp%100/10, temp%10%100);   
	}  
}