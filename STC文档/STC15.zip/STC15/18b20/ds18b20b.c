#include"d18b20.h"

void delay(uint t)
{
	uint i;
	for(i = 0; i<t; i++)
	{
		_nop_();	 //1.0us
	}
			  
}
  
bit init_ds18b20(void)
{
	bit initflag = 0;
	DQ = 1;
	delay(10);
	DQ = 0;
	delay(500);
	DQ = 1;
	delay(200);
	initflag = DQ;
	delay(250);

	return initflag;
}
//ͨ��������������дһ���ֽ�
void wr_ds18b20(uchar dat)
{
	uchar i;
	for(i = 0; i<8; i++)
	{
		DQ = 0;
		delay(2);
		DQ = dat&0x01;
		delay(60);
		DQ = 1;
		dat >>= 1;

	}
	delay(5);
}
//ͨ�������ߴ�������һ���ֽ�
uchar rd_ds18b20(void)
{
	uchar i;
	uchar ret;
	uchar dat = '0';
	for(i = 0; i<8; i++)
	{	
		dat >>= 1;
		DQ = 0;
		delay(2);
		DQ = 1;
		ret = DQ;
		delay(60);
		DQ = 1;
		if(ret)
			dat |= 0x80;
	}
	return dat;
}

///�¶�ת������
uchar rd_temperature(void)
{
	uchar low, high;
	uint temp;

	float temperature;

	DQ = 1;
	init_ds18b20();
	wr_ds18b20(0xcc);
	wr_ds18b20(0x44);
	delay(200);

	init_ds18b20();
	wr_ds18b20(0xcc);
	wr_ds18b20(0xbe);
	//delay(125);

	low = rd_ds18b20();	 //���ֽ�
	high = rd_ds18b20();	  //���ֽ�
	
//	temp = high<<4;
//	temp |= (low>>4);

	temp = high&0x0f;
	temp <<= 8;
	temp |= low;
		
	temperature=temp*0.0625;
	temp=temperature*10+0.5;

	return temp;
 
}