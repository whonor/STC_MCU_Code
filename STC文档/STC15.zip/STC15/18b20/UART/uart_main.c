#include"d18b20.h"

uint tflag;
bit secflag = 0;
uchar text[] = "temperature = ";
uchar enter[] = {0x0A, 0x0D};

void uart_tx(uchar *p, uchar length);
char dat(char a);

void main(void)
{
	uchar temp;

	SCON = 0x50;
	TMOD = 0x22;
	TL1 = 0xf3;
	TH1 = 0xf3;

	TL0 = 0x06;
	TH0 = 0x06;
	EA = 1;
	ET0 = 1;

	TR0 = 1;
	TR1 = 1;

	while(1)
	{
		if(secflag == 1)
		{
			secflag = 0;
			uart_tx(text, 14);

			temp = rd_temperature;

			if(temp > 99)
			{
				SBUF = temp/100+0x30;
				while(TI == 0);
				TI = 0;

			}
			if(temp > 9)
			{
				SBUF = temp%100/10+0x30;
				while(TI == 0);
				TI = 0;
			}
			SBUF = temp%100%10 + 0x30;
			while(TI == 0);
			TI = 0;

		}
	}
}


void T0_time(void) interrupt 1
{
	tflag++;
	if(tflag == 4000)
	{
		tflag = 0;
		secflag = 1;

	}
}


void uart_tx(uchar *p, uchar length)
{
	uchar i;
	for(i = 0; i<length; i++)
	{
		SBUF = *(p+1);
		while(TI == 0);
		TI = 0;

	}
}

