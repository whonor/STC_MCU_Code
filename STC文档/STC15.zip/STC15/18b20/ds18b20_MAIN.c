#include "d18b20.h"
#define Y5C 0xa0;
#define Y6C 0xc0;
#define Y7C 0xe0;

//uchar smg_change[6]={10,10,10,10,10,10};

uchar code table_d[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,		 //0~9
						0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10}; //��С����0~9
//uchar code table_w[] = {0x80, 0x40, 0x20, 0x01, 0x08, 0x04, 0x02, 0x01, 0xbf};//λѡ��


/*
void initT0(void)
{
	//AUXR &= 0x7F;		//��ʱ��ʱ��12Tģʽ
	TMOD = 0x00;		//���ö�ʱ��ģʽ
	TL0 = 0x66;		//���ö�ʱ��ֵ
	TH0 = 0xFC;		//���ö�ʱ��ֵ
	//TF0 = 0;		//���TF0��־
	TR0 = 1;
	ET0 = 1;
	EA = 1; 
}
*/


void display(uint tem)
{
	uchar bai,shi,ge;
	bai=tem/100;
	shi=tem%100/10;
	ge=tem%100%10;

//	P0 = 0xff;
	P2 &= 0x1f;
	P2 |= Y6C;//��Y6 
	P0 = 0x80;
	P2 &= 0x1f;
	P2 |= Y7C;//��Y7
	P0 = table_d[ge];		
	delay(50);
	P0 = 0xff;

	P2 &= 0x1f;
	P2 |= Y6C;//��Y6 
	P0 = 0x40;
	P2 &= 0x1f;
	P2 |= Y7C;//��Y7	
	P0 = table_d[10+shi];
	delay(50);
	P0 = 0xff;

	P2 &= 0x1f; 
	P2 |= Y6C;//��Y6 
	P0 = 0x20;
	P2 &= 0x1f;
	P2 |= Y7C;//��Y7
	P0 = table_d[bai]; 
	delay(50);
	P0 = 0xff;

}


void main(void)
{
	P0 = 0xff;
	P2 |= Y5C;
	P0 = 0x00;
	P2 &= 0x1f;
	while(1)
	{
		
//			EA = 0;
			display(rd_temperature());
			//rd_temperature();
//			EA = 1;
		
		
	}
}
