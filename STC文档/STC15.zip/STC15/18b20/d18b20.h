#ifndef _D18B20_H_
#define _D18B20_H_
#define uint unsigned int
#define uchar unsigned char

#include <reg52.h>
#include <intrins.h>

sbit DQ = P1^4;

bit init_ds18b20(void);
void wr_ds18b20(uchar dat);
uchar rd_ds18b20(void);
uchar rd_temperature(void);
void delay(uint t);
//uint rd_temp(void);
//void StartConvert(void);

#endif
