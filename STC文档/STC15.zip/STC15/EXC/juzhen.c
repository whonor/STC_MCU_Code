/*
//�������ʵ��
//CT107D
*/

#include<reg52.h>
//include"stc15f2k60s2.h"
#include<intrins.h>
#define uchar unsigned char
#define Y7C 111000000
#define Y6C 11000000

sbit r1 = P3^0;
sbit r2 = P3^1;
sbit r3 = P3^2;
sbit r4 = P3^3;

sbit c1 = P4^4;		//ԭ��ͼ�в��ԣ�Ӧ����P4
sbit c2 = P4^2;
sbit c3 = P3^5;
sbit c4 = P3^4;
uchar key_value;
uchar code table[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};  //0~9


////////////////////////////////////////////////////
//�������ʾ
void display(uchar v)
{
	P2 &= 0x1f;
	P2 |= Y7C;
	P0 = table[v];
}
//////////////////////////////////////////////////////////
//�������ɨ�躯��
uchar key_scan()
{
	
	//r1=0;
     //r2=r3=r4=1;
     //c1=c2=c3=c4=1;��
	 P3 = 0xfe;
     if(!c1) 
	 {
	 	_nop_();
	 	if(!c1)
		{
			_nop_();
			key_value=0;	
		}
		while(!c1);

	 }
     else if(!c2) 
	 {
	 	_nop_();
	 	if(!c2)
		{
			_nop_();
			key_value=1;
		}
		while(!c2);
	 }
     else if(!c3) 
	 {
	 	_nop_();
	 	if(!c3)
		{
			_nop_();
			key_value=2;	
		}
		while(!c3);
	 }
     else if(!c4) 
	 {
	 	_nop_();
	 	if(!c4)
		{
			_nop_();
			key_value=3;
		}
		while(!c4);
	 }
    //r2=0;
     //r1=r3=r4=1;
     //c1=c2=c3=c4=1;
 	 P3 = 0xfd;
     if(!c1) 
	 {
	 	_nop_();
	 	if(!c1)
		{
			_nop_();
			key_value=4;
		}
		while(!c1);
	 }
     else if(!c2) 
	 {
	 	_nop_();
	 	if(!c2)
		{
			_nop_();
			key_value=5;
		}
		while(!c2);
	 }
     else if(!c3) 
	 {
	 	_nop_();
	 	if(!c3)
		{
			_nop_();
			key_value=6;
		}
		while(!c3);
	 }
     else if(!c4)
	 {
	 	_nop_();
	 	if(!c4)
		{
			_nop_();
			key_value=7;
		}
		while(!c4);
	 } 
 
    //r3=0;
     //r2=r1=r4=1;
     //c1=c2=c3=c4=1;
 	 P3 = 0xfb;
     if(!c1)
	 {
	 	_nop_();
	 	if(!c1)
		{
			_nop_();
			key_value=8;
		}
		while(!c1);
	 } 
     else if(!c2)
	 {
	 	_nop_();
	 	if(!c2)
		{
			_nop_();
			key_value=9;
		}
		while(!c2);
	 } 
     else if(!c3)
	 {
	 	_nop_();
	 	if(!c3)
		{
			_nop_();
			key_value=10;
		}
		while(!c3);
	 } 
     else if(!c4)
	 {
	 	_nop_();
	 	if(!c4)
		{
			_nop_();
			key_value=11;
		}
		while(!c4);
	 } 
 
     //r4=0;
     //r2=r3=r1=1;
     //c1=c2=c3=c4=1;
 	 P3 = 0xf7;
     if(!c1)
	 {
	 	_nop_();
	 	if(!c1)
		{
			_nop_();
			key_value=12;
		}
		while(!c1);
	 } 
     else if(!c2)
	 {
	 	_nop_();
	 	if(!c2)
		{
			_nop_();
			key_value=13;
		}
		while(!c2);
	 } 
     else if(!c3)
	 {
	 	_nop_();
	 	if(!c3)
		{
			_nop_();
			key_value=14;
		}
		while(!c3);
	 } 
     else if(!c4)
	 {
	 	_nop_();
	 	if(!c4)
		{
			_nop_();
			key_value=15;
		}
		while(!c4);
	 } 
 
     return key_value;
}
////////////////////////////////////////////////////
void main(void)
{
	uchar value; 
	P2 &= 0x1f;
	P2 |= Y6C;
	P0 = 0x7f;
	
	while(1)
	{
		value = key_scan();
		switch(value)
		{
			case 0:
			display(0);
			break;
			case 1:
			display(1);
			break;
			case 2:
			display(2);
			break;
			case 3:
			display(3);
			break;
			case 4:
			display(4);
			break;
			case 5:
			display(5);
			break;
			case 6:
			display(6);
			break;
			case 7:
			display(7);
			break;
			case 8:
			display(8);
			break;
			case 9:
			display(9);
			break;
			default:
			break;
		}
	}
}