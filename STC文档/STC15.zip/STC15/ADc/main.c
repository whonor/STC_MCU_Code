#include"adc_pcf8591.h"

void init_t0(void);
void init_pcf8591(void);
void display(uchar d);

bit adcflag = 0;
uchar dspflag;
uchar tflag1; 
uchar tflag2;
uchar code dsp_code[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80, 0x90};

void main(void)
{
	uchar adcvalue;
	init_pcf8591();
	init_t0();
	while(1)
	{
		
		 if(adcflag == 1)
		 {
		 	 adcvalue = adc_pcf8591(); 
			 
			 adcflag = 0;
		 }
		 display(adcvalue);
	}
}


void T0_time(void) interrupt 1
{
	tflag1++;
	tflag2++;
	if(tflag1 == 16)
	{
		tflag1 =  0;
		dspflag++;
		if(dspflag == 3)
			dspflag = 0;
	}
	if(tflag2 == 80)
	{
		tflag2 = 0;
		adcflag = 1;
	}	
	
}

void init_t0(void)
{
	TMOD = 0x02;
	TL0 = 0x06;
	TH0 = 0x06;
	 ET0 = 1;
	 TR0 = 1;
	 EA = 1;
	  
}

void  init_pcf8591(void)
{
	iic_start();
	iic_sendbyte(0x90);
	iic_waitack();
	iic_sendbyte(CHANNEL_3);
	iic_waitack();
	iic_stop();
	delay(10);
}


void display(uchar d)
{
	if((dspflag == 0) && (d>99))
	{
		P0 = 0xff;
		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = dsp_code[d/100];

		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = 0x20;

		 P2 |= 0xc0;
		 P2 &= 0x3f;
	}

	if((dspflag == 1) && (d>9))
	{
		P0 = 0xff;
		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = dsp_code[d%100/10];

		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = 0x40;
		 P2 |= 0xc0;
		 P2 &= 0x3f;
	}

	if(dspflag == 2) 
	{
		P0 = 0xff;
		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = dsp_code[d%10];

		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = 0x80;

		 P2 |= 0xc0;
		 P2 &= 0x3f;
	}
/*	if(dspflag == 3) 
	{
		P0 = 0xff;
		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = dsp_code[d%1000%100%10];

		 P2 |= 0xe0;
		 P2 &= 0x1f;
		 P0 = 0x80;

		 P2 |= 0xc0;
		 P2 &= 0x3f;
	}
 */
}
