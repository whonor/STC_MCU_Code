#include"AT24C02.h"

void iic_delay(uchar m)
{
	do
	{
		_nop_();
	}
	while(m--);
}


void iic_start(void)
{
	sda=1;
	_nop_();
	scl=1;
	_nop_();
	sda=0;
	_nop_();
	scl=0;
	_nop_();
}


void iic_stop(void)
{
	sda=0;
	_nop_();
	scl=1;
	_nop_();
	sda=1;
	_nop_();
}


void writebyte(uchar dat)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		scl=0;
		sda=dat&0x80;
		scl=1;
		dat<<=1;
	}
	scl=0;
}


uchar readbyte(void)
{
	uchar dat;
	uchar i;
	for(i=0;i<8;i++)
	{
		scl=1;
		iic_delay(5);
		dat<<=1;
		if(sda)
		{
			dat|=0x01;
		}
		scl=0;
	}
	
	return dat;
}

uchar ack(void)
{
	scl=1;
	iic_delay(5);
	if(sda==1)
	{
		scl=0;
		iic_stop();
		return 0;
	}
	else 
	{
		scl=0;
		return 1;
	}
}



void iic_write(uchar add,uchar dat)// ADת��û�е���
{
	iic_start();
	writebyte(0xA0);//EEPROMΪ0xA0
	ack();
	writebyte(add);
	ack();
	writebyte(dat);
	ack();
	iic_stop();
}

uchar iic_read(uchar add)
{
	uchar temp;
	
	iic_start();
	writebyte(0xA0);//EEPROMΪ0xA0
	ack();
	writebyte(add);
	ack();
	iic_stop();
	
	iic_start();
	writebyte(0xA1);//EEPROMΪ0xA1
	ack();
	temp=readbyte();
	iic_stop();
	
	temp=0.39*temp;
	
	return temp;
}