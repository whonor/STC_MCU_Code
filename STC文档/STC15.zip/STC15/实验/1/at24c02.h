#ifndef _AT24C02_H_
#define _AT24C02_H_

#include<reg52.h>
#include<intrins.h>

#define uchar unsigned char 
#define uint unsigned int

sbit scl=P2^0;
sbit sda=P2^1;

void iic_delay(uchar m);
void iic_start(void);
void iic_stop(void);
void writebyte(uchar dat);
uchar readbyte(void);
uchar ack(void);
void iic_write(uchar add,uchar dat);
uchar iic_read(uchar add);


#endif