#ifndef _KEYBOARD_H__
#define _KEYBOARD_H__
#include "STC15F2K60S2.h"
#include "iic.h"
unsigned char KeyBoard(void);
void Delay75ms();
#endif