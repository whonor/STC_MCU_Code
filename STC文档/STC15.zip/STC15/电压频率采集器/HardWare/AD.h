#ifndef _AD_H__
#define _AD_H__
#include "STC15F2K60S2.h"
#include "iic.h"
void InitPCF8591(void);
unsigned char ReadPCF8591(void);
#endif