#ifndef _EEPROM_H__
#define _EEPROM_H__
#include "STC15F2K60S2.h"
#include "iic.h"
void WriteEEPROM(unsigned char Addr,unsigned char Value);
unsigned char ReadEEPROM(unsigned char Addr);

#endif