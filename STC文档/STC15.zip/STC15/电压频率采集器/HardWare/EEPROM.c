#include "EEPROM.h"
void WriteEEPROM(unsigned char Addr,unsigned char Value)
{
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_WaitAck();
	IIC_SendByte(Addr);
	IIC_WaitAck();
	IIC_SendByte(Value);
	IIC_WaitAck();
	IIC_Stop();
	somenop;
}
unsigned char ReadEEPROM(unsigned char Addr)
{
	unsigned char temp;
	IIC_Start();
	IIC_SendByte(0xA0);
	IIC_WaitAck();
	IIC_SendByte(Addr);
	IIC_WaitAck();
	IIC_Start();
	IIC_SendByte(0xA1);
	IIC_WaitAck();
	temp=IIC_RecByte();
	IIC_Ack(0);
	IIC_Stop();
	somenop;
	return temp;
}