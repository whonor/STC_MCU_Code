#include "KeyBoard.h"
unsigned char theKeyValue;
unsigned char KeyPress;
sbit p42=P4^2;
sbit p44=P4^4;
void Delay75ms()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	i = 2;
	j = 170;
	do
	{
		while (--j);
	} while (--i);
}
unsigned char KeyBoard(void)
{
	static unsigned char Col;
	P3=0xF0;
	p42=1;
	p44=1;
	theKeyValue=0;
	if(P3!=0xF0||p42!=1||p44!=1)
	{
		 Delay75ms();
		if(P3!=0xF0||p42!=1||p44!=1)
			KeyPress++;
		else
			KeyPress=0;
	}
	else
		KeyPress=0;
	if(KeyPress==1)
	{
		KeyPress=0;
		if(p44==0)        Col=1;
		if(p42==0)        Col=2;
		if((P3&0x20)==0)  Col=3;
		if((P3&0x10)==0)  Col=4;
		
		P3=0x0F;
		p42=0;
		p44=0;
		
		if((P3&0x08)==0)  theKeyValue=Col*4+0;
		if((P3&0x04)==0)  theKeyValue=Col*4+1;
		if((P3&0x02)==0)  theKeyValue=Col*4+2;
		if((P3&0x01)==0)  theKeyValue=Col*4+3;
	}
	return theKeyValue;
}