#include "AD.h"
void InitPCF8591(void)
{
	 IIC_Start();
	 IIC_SendByte(0x90);
	 IIC_WaitAck();
	 IIC_SendByte(0x03);
	 IIC_WaitAck();
	 IIC_Stop();
	 somenop;
}
unsigned char ReadPCF8591(void)
{
	unsigned char temp;
	 IIC_Start();
	 IIC_SendByte(0x91);
	 IIC_WaitAck();
	 temp=IIC_RecByte();
	 IIC_Ack(0);
	 IIC_Stop();
	 somenop;
	 return temp;
}