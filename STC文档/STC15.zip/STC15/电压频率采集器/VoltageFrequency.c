#include "STC15F2K60S2.h"
#include "KeyBoard.h"
#include "EEPROM.h"
#include "ds1302.h"
#include "AD.h"


sbit GATE=P3^2;
#define FOSC 11059200L
#define Million 1000000L
#define TIMS 65536-FOSC/1000
#define ds1302_sec_addrEX			0x81		//�����ݵ�ַ
#define ds1302_min_addrEX			0x83		//�����ݵ�ַ
#define ds1302_hr_addrEX			0x85		//ʱ���ݵ�ַ
#define ds1302_date_addrEX		0x87		//�����ݵ�ַ
#define ds1302_month_addrEX		0x89		//�����ݵ�ַ
#define ds1302_day_addrEX			0x8B		//�������ݵ�ַ
#define ds1302_year_addrEX		0x8D		//�����ݵ�ַ

unsigned char Count0;                 //����ܼ�����
unsigned char Count1;                 //ʱ��������������
unsigned int Count2;                  //1000HZ��Ƶ��
unsigned char Count3;                 //100HZ��Ƶ��
unsigned char Count4;                 //EEPROMд���ݼ�����
unsigned char Count5;
unsigned int Count6;                  //500ms����������
unsigned char KeyValue;               //��ֵ
unsigned char BlinkFlag;              //��˸��־λ
unsigned int Voltage;                 //��ǰ��ѹֵ
unsigned int HighVoltage=5000;        //��ѹ����ֵ
unsigned int LowVoltage=500;          //��ѹ����ֵ
unsigned int Frequency;               //����Ƶ��ֵ
unsigned int Period;                  //��������ֵ
unsigned int Count7;                  //�������
unsigned int Count8;
unsigned char tab[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,
0x88,0x83,0xC6,0xA1,0x86,0xBE,0xBF,0xFF};
unsigned char wei[]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
unsigned char ReadDS1302Addr[]={ds1302_hr_addrEX,ds1302_min_addrEX,ds1302_sec_addrEX,
ds1302_year_addrEX,ds1302_month_addrEX,ds1302_date_addrEX,ds1302_day_addrEX};
unsigned char DateInit[7]={0x23,0x59,0x55,0x31,0x03,0x17,0x05};
unsigned char Time[4];                 //��ǰʱ��ֵ
unsigned char SaveDataCount[4]={0x00,0x01,0x02,0x03};
unsigned char SaveDataCount2[4]={0x10,0x21,0x22,0x23};
unsigned char SaveData[4];
unsigned char SaveTimeData[4];            
unsigned TemperaryData[3];
bit TemperarySingleData;
bit KeyFlag4;                          //ʱ�����λ�仯��־λ
bit KeyFlag5;                          //Ƶ�ʲ�����־λ
bit KeyFlag7;                          //ʱ������־λ
bit KeyFlag6;                          //����6���±�־λ
bit KeyFlag9;                          //��ѯ��־λ
bit KeyFlag8;                          //����ռ�ձȱ�־λ
bit SubstractFlag;                     //ʱ���������־λ
bit PlusFlag;                          //ʱ���������־λ
bit VoltageFlag;                       //��ѹ�����־λ
bit ReadFlag;                          //������־λ
bit VoltageThresholdFlag;              //��ѹ��ֵ���ñ�־λ
bit CirculFlag;                        //ѭ����˸��־λ��ѹ��ֵ
bit SaveFlag;                          //�洢��ѹ��ֵ��־λ
bit VoltageCheckFlag;                  //��ѹ����־λ
bit ThingType;                         //�¼�����
bit SaveTimeFlag;                      //�洢ʱ���־λ
bit DemandFlag;                        //�¼������л���־λ
bit FrequencyFlag;                     //Ƶ��������ʾ��־λ
bit Time500;                           //500ms������־λ
bit FrequencyCirculFlag;               //Ƶ������ѭ����־λ
bit DutyCycleFlag;
void TimerConfiguration();
void Display();
void Select(unsigned char theNum);
void InitDS1302();
void ReadDS1302();
void MeasureVoltage();
void CorrectTime();
void CorrectVoltage();
void CheckVoltage();
void Demand();
void MeasureFrequency();
void MeasureDutyCycle();

//������
void main(void)
{
	unsigned int temp=0;
	P0=0x00;
	P2=((P2&0x1F)|0xA0);
	P2&=0x1F;
	TimerConfiguration();
	InitDS1302();
	InitPCF8591();
	
LowVoltage=ReadEEPROM(0x00);
temp=ReadEEPROM(0x01);
LowVoltage|=(temp<<8);
	temp=0;
HighVoltage=ReadEEPROM(0x02);
temp=ReadEEPROM(0x03);
HighVoltage|=(temp<<8);
	Count4=5;
	Count5=5;
	Voltage=(HighVoltage+LowVoltage)/2;
		TR0=0;
	while(1)
	{
		if(ReadFlag)
		{
			ReadFlag=0;
			MeasureVoltage();
		}
		KeyValue=KeyBoard();
		ReadDS1302();
		CorrectTime();
    CorrectVoltage();
		CheckVoltage();
		Demand();
		MeasureFrequency();
		//MeasureDutyCycle();
	}
}

//��ʱ��������ú���
void TimerConfiguration()
{
	AUXR=0xC5;
	TMOD=0x05;
	TL1=TIMS;
	TH1=TIMS>>8;
	TR1=1;
	TH0=0;
	TL0=0;
	ET1=1;
	EA=1;
}

//��ʱ��1�Ӻ���
void Timer1IRQ() interrupt 3
{
	Display();
	Count2++;
	Count3++;
	if(Time500)
	{
		Count6++;
		if(Count6==1000)
		{
			Time500=0;
			Count6=0;
		}
	}
	if(Count2==1000)
	{
		Count2=0;
	}
	if(Count3==100)
	{
		Count3=0;
		ReadFlag=1;
		if(Count4<4)
	   SaveFlag=1;
		if(Count5<4)
			SaveTimeFlag=1;
	}
}

//�������ʾ
void Display()
{
	P0=0xFF;
	P2=((P2&0x1F)|0xE0);
	P2&=0x1F;
	P0=wei[Count0];
	P2=((P2&0x1F)|0xC0);
	P2&=0x1F;
	Select(Count0);
	P2=((P2&0x1F)|0xE0);
	P2&=0x1F;
	Count0++;
	if(Count0==8)
		Count0=0;
}

//
void Select(unsigned char theNum)
{
	 if(DutyCycleFlag)
		{
			switch(theNum)
			{
		case 0:P0=tab[Count8%10];break;
		case 1:P0=tab[Count8/10%10];break;
		case 2:P0=tab[Count8/100%10];break;
		case 3:P0=tab[Count8/1000];break;
	  case 4:P0=tab[17];break;
		case 5:P0=tab[16];break;
	  case 6:P0=tab[3];break;
		case 7:P0=tab[16];break;
		default:P0=0xFF;
			}
		}
		else if(FrequencyFlag)
		{
			if(FrequencyCirculFlag)
			{
				switch(theNum)
			{
		case 0:P0=tab[Frequency%10];break;
		case 1:P0=tab[Frequency/10%10];break;
		case 2:P0=tab[Frequency/100%10];break;
		case 3:P0=tab[Frequency/1000%10];break;
	  case 4:P0=tab[Frequency/10000];break;
		case 5:P0=tab[16];break;
	  case 6:P0=tab[2];break;
		case 7:P0=tab[16];break;
		default:P0=0xFF;
			}
		}
			else
			{
			  switch(theNum)
			{
		case 0:P0=tab[Period%10];break;
		case 1:P0=tab[Period/10%10];break;
		case 2:P0=tab[Period/100%10];break;
		case 3:P0=tab[Period/1000%10];break;
	  case 4:P0=tab[Period/10000];break;
		case 5:P0=tab[16];break;
	  case 6:P0=tab[2];break;
		case 7:P0=tab[16];break;
		default:P0=0xFF;
			}
			}

		}
	  else  if(VoltageCheckFlag)
	{
		if(!DemandFlag)
	{
			switch(theNum)
		{
		case 0:P0=tab[TemperarySingleData];break;
		case 1:P0=tab[0];break;
		case 2:P0=tab[17];break;
		case 3:P0=tab[17];break;
	  case 4:P0=tab[17];break;
		case 5:P0=tab[17];break;
	  case 6:P0=tab[17];break;
		case 7:P0=tab[17];break;
		default:P0=0xFF;
	}
}
	else
	{
		  switch(theNum)
	{
		case 0:P0=tab[TemperaryData[0]&0x0F];break;
		case 1:P0=tab[TemperaryData[0]>>4];break;
		case 2:P0=tab[16];break;
		case 3:P0=tab[TemperaryData[1]&0x0F];break;
	  case 4:P0=tab[TemperaryData[1]>>4];break;
		case 5:P0=tab[16];break;
	  case 6:P0=tab[TemperaryData[2]&0x0F];break;
		case 7:P0=tab[TemperaryData[2]>>4];break;
		default:P0=0xFF;
	}
}
}

		else if(VoltageFlag)
		{
			switch(theNum)
			{
		case 0:P0=tab[Voltage%10];break;
		case 1:P0=tab[Voltage/10%10];break;
		case 2:P0=tab[Voltage/100%10];break;
		case 3:P0=tab[Voltage/1000];break;
	  case 4:P0=tab[17];break;
		case 5:P0=tab[16];break;
	  case 6:P0=tab[1];break;
		case 7:P0=tab[16];break;
		default:P0=0xFF;
			}
		}
		else if(VoltageThresholdFlag)
		{
			switch(theNum)
	{
		case 0:if(CirculFlag){if(Count2>500)P0=tab[LowVoltage%10];else P0=0xFF;} else P0=tab[LowVoltage%10];break;
		case 1:if(CirculFlag){if(Count2>500)P0=tab[LowVoltage/10%10];else P0=0xFF;} else P0=tab[LowVoltage/10%10];break;
		case 2:if(CirculFlag){if(Count2>500)P0=tab[LowVoltage/100%10];else P0=0xFF;} else P0=tab[LowVoltage/100%10];break;
		case 3:if(CirculFlag){if(Count2>500)P0=tab[LowVoltage/1000];else P0=0xFF;} else P0=tab[LowVoltage/1000];break;
	  case 4:if(!CirculFlag){if(Count2>500)P0=tab[HighVoltage%10];else P0=0xFF;} else P0=tab[HighVoltage%10];break;
		case 5:if(!CirculFlag){if(Count2>500)P0=tab[HighVoltage/10%10];else P0=0xFF;} else P0=tab[HighVoltage/10%10];break;
	  case 6:if(!CirculFlag){if(Count2>500)P0=tab[HighVoltage/100%10];else P0=0xFF;} else P0=tab[HighVoltage/100%10];break;
		case 7:if(!CirculFlag){if(Count2>500)P0=tab[HighVoltage/1000];else P0=0xFF;} else P0=tab[HighVoltage/1000];break;
		default:P0=0xFF;
	}
		}
		else if(BlinkFlag)
		{
			switch(theNum)
			{
				case 0:if(BlinkFlag==1){ if(Count2>500)P0=tab[Time[2]&0x0F];else P0=0xFF;} else P0=tab[Time[2]&0x0F];break;
				case 1:if(BlinkFlag==1){ if(Count2>500)P0=tab[Time[2]>>4];else P0=0xFF;} else P0=tab[Time[2]>>4];break;
				case 2:P0=tab[16];break;
				case 3:if(BlinkFlag==2){ if(Count2>500)P0=tab[Time[1]&0x0F];else P0=0xFF;} else P0=tab[Time[1]&0x0F];break;
				case 4:if(BlinkFlag==2){ if(Count2>500)P0=tab[Time[1]>>4];else P0=0xFF;} else P0=tab[Time[1]>>4];break;
				case 5:P0=tab[16];break;
				case 6:if(BlinkFlag==3){ if(Count2>500)P0=tab[Time[0]&0x0F];else P0=0xFF;} else P0=tab[Time[0]&0x0F];break;
				case 7:if(BlinkFlag==3){ if(Count2>500)P0=tab[Time[0]>>4];else P0=0xFF;} else P0=tab[Time[0]>>4];break;
				default:P0=0xFF;
			}
		}
		else
		{
			switch(theNum)
			{
				case 0:P0=tab[Time[2]&0x0F];break;
				case 1:P0=tab[Time[2]>>4];break;
				case 2:P0=tab[16];break;
				case 3:P0=tab[Time[1]&0x0F];break;
				case 4:P0=tab[Time[1]>>4];break;
				case 5:P0=tab[16];break;
				case 6:P0=tab[Time[0]&0x0F];break;
				case 7:P0=tab[Time[0]>>4];break;
				default:P0=0xFF;
			}
		}
}

//��ʼ��DS1302
void InitDS1302()
{
	Ds1302_Single_Byte_Write(ds1302_control_addr,0x00);
	Ds1302_Single_Byte_Write(ds1302_sec_addr,DateInit[2]);
	Ds1302_Single_Byte_Write(ds1302_min_addr,DateInit[1]);
	Ds1302_Single_Byte_Write(ds1302_hr_addr,DateInit[0]);
	Ds1302_Single_Byte_Write(ds1302_date_addr,DateInit[3]);
	Ds1302_Single_Byte_Write(ds1302_month_addr,DateInit[4]);
	Ds1302_Single_Byte_Write(ds1302_year_addr,DateInit[5]);
	Ds1302_Single_Byte_Write(ds1302_day_addr,DateInit[6]);
	Ds1302_Single_Byte_Write(ds1302_charger_addr,0x00);
	Ds1302_Single_Byte_Write(0xC0,0xF0);
	Ds1302_Single_Byte_Write(ds1302_control_addr,0x80);
}
void ReadDS1302()
{
	unsigned char temp,i;
	for(i=0;i<3;i++)
	{
		temp=Ds1302_Single_Byte_Read(ReadDS1302Addr[i]);
		Time[i]=temp;
		DateInit[i]=Time[i];
		Delay75ms();
	}
}

//��ѹ����
void MeasureVoltage()
{
	unsigned int temp;
	temp=ReadPCF8591();
	Voltage=(unsigned int)temp*19.6;
}
void CorrectTime()
{
		unsigned char Date[4];                       //���ʱ������
 if(VoltageFlag==0&&VoltageThresholdFlag==0&&VoltageCheckFlag==0&&FrequencyFlag==0&&DutyCycleFlag==0)     //ʱ�����
{
		if(KeyFlag4==0&&KeyValue==4)
 {
	 KeyFlag4=1;
 }
 if(KeyFlag4==1&&KeyValue==0)
 {
	 KeyFlag4=0;
	 Count1++;
	 if(Count1==4)
		 Count1=1;
	 Delay75ms();
 }
}
 if(Count1==1)
 {
	 BlinkFlag=1;
	 Date[0]=Ds1302_Single_Byte_Read(ds1302_sec_addrEX);
	 if(SubstractFlag==0&&KeyValue==10)
	 {
		 SubstractFlag=1;
	 }
	 if(SubstractFlag==1&KeyValue==0)
	 {
		 SubstractFlag=0;
		 Date[0]--;
		 if(Date[0]%16==0x0F)
			 Date[0]-=0x06;
		 if(Date[0]==0x00)
			 Date[0]=0x59;
		 DateInit[2]=Date[0];
		 InitDS1302();
	 }
	 if(PlusFlag==0&&KeyValue==11)
	 {
		 PlusFlag=1;
	 }
	 if(PlusFlag==1&KeyValue==0)
	 {
		 PlusFlag=0;
		 Date[0]++;
		 if(Date[0]%16==0x0a)
			 Date[0]+=0x06;
		 if(Date[0]>0x59)
			 Date[0]=0x00;
		 DateInit[2]=Date[0];
		 InitDS1302();
	 }
 }
 else if(Count1==2)
 {
	 BlinkFlag=2;
	 Date[1]=Ds1302_Single_Byte_Read(ds1302_min_addrEX);
	 if(SubstractFlag==0&&KeyValue==10)
	 {
		 SubstractFlag=1;
	 }
	 if(SubstractFlag==1&KeyValue==0)
	 {
		 SubstractFlag=0;
		 Date[1]--;
		 if(Date[1]%16==0x0F)
			 Date[1]-=0x06;
		 if(Date[1]>=0x59)
			 Date[1]=0x59;
		 DateInit[1]=Date[1];
		 InitDS1302();
	 }
	 if(PlusFlag==0&&KeyValue==11)
	 {
		 PlusFlag=1;
	 }
	 if(PlusFlag==1&KeyValue==0)
	 {
		 PlusFlag=0;
		 Date[1]++;
		 if(Date[1]%16==0x0a)
			 Date[1]+=0x06;
		 if(Date[1]>0x59)
			 Date[1]=0x00;
		 DateInit[1]=Date[1];
		 InitDS1302();
	 }
 }
 else if(Count1==3)
 {
	 BlinkFlag=3;
	 Date[2]=Ds1302_Single_Byte_Read(ds1302_hr_addrEX);
	 if(SubstractFlag==0&&KeyValue==10)
	 {
		 SubstractFlag=1;
	 }
	 if(SubstractFlag==1&KeyValue==0)
	 {
		 SubstractFlag=0;
		 Date[2]--;
		 if(Date[2]%16==0x0F)
			 Date[2]-=0x06;
		 if(Date[2]>=0x24)
			 Date[2]=0x23;
		 DateInit[0]=Date[2];
		 InitDS1302();
	 }
	 if(PlusFlag==0&&KeyValue==11)
	 {
		 PlusFlag=1;
	 }
	 if(PlusFlag==1&KeyValue==0)
	 {
		 PlusFlag=0;
		 Date[2]++;
		 if(Date[2]%16==0x0a)
			 Date[2]+=0x06;
		 if(Date[2]>0x23)
			 Date[2]=0x00;
		 DateInit[0]=Date[2];
		 InitDS1302();
	 }
 }
 if(KeyFlag7==0&&KeyValue==7)
 {
	 KeyFlag7=1;
 }
 if(KeyFlag7==1&&KeyValue==0)
 {
	 KeyFlag7=0;
	 Count1=0;
	 BlinkFlag=0;
	 VoltageFlag=0;
	 VoltageThresholdFlag=0;
	 VoltageCheckFlag=0;
	 FrequencyFlag=0;
	 DutyCycleFlag=0;
 }
}
void CorrectVoltage()
{
	if(KeyFlag6==0&&KeyValue==6)
 {
	 KeyFlag6=1;
 }
 if(KeyFlag6==1&&KeyValue==0)
 {
	 KeyFlag6=0;
	 VoltageFlag=1;
	 VoltageCheckFlag=0;
	 FrequencyFlag=0;
	 DutyCycleFlag=0;
	 SaveFlag=1;
	 Count4=0;
	 	SaveData[0]=LowVoltage;
		SaveData[1]=LowVoltage>>8;
		SaveData[2]=HighVoltage;
		SaveData[3]=HighVoltage>>8;
 }
 if(SaveFlag)
 {
	 SaveFlag=0;
	 WriteEEPROM(SaveDataCount[Count4],SaveData[Count4]);
	 Count4++;
 }
 if(VoltageFlag==1&&VoltageCheckFlag==0&&FrequencyFlag==0&&DutyCycleFlag==0)
 {
	 	if(KeyFlag4==0&&KeyValue==4)
 {
	 KeyFlag4=1;
 }
 if(KeyFlag4==1&&KeyValue==0)
 {
	 KeyFlag4=0;
     VoltageFlag=0;
	 VoltageThresholdFlag=1;
 }
 }
 if(VoltageThresholdFlag==1&&FrequencyFlag==0&&DutyCycleFlag==0)
 {
	 if(KeyFlag4==0&&KeyValue==4)
 {
	 KeyFlag4=1;
 }
 if(KeyFlag4==1&&KeyValue==0)
 {
	 KeyFlag4=0;
	 CirculFlag=~CirculFlag;
 }
 }
 if(CirculFlag)
 {
	 if(PlusFlag==0&&KeyValue==11)
	 {
		 PlusFlag=1;
	 }
	 if(PlusFlag==1&&KeyValue==0)
	 {
		 if(LowVoltage<HighVoltage)
			 LowVoltage+=500;
		 PlusFlag=0;
	 }
	 if(SubstractFlag==0&&KeyValue==10)
	 {
		 SubstractFlag=1;
	 }
	 if(SubstractFlag==1&&KeyValue==0)
	 {
		 if(LowVoltage>0)
		 LowVoltage-=500;
		 SubstractFlag=0;
	 }
 }
 else 
 {
	 if(PlusFlag==0&&KeyValue==11)
	 {
		 PlusFlag=1;
	 }
	 if(PlusFlag==1&&KeyValue==0)
	 {
		 if(HighVoltage<9500)
		 HighVoltage+=500;
		 PlusFlag=0;
	 }
	 if(SubstractFlag==0&&KeyValue==10)
	 {
		 SubstractFlag=1;
	 }
	 if(SubstractFlag==1&&KeyValue==0)
	 {
		 if(HighVoltage>LowVoltage)
		 HighVoltage-=500;
		 SubstractFlag=0;
	 }
 }
}
void CheckVoltage()
{
	if(Voltage<LowVoltage)
	{
		Count5=0;
		ThingType=0;
		SaveTimeFlag=1;
		SaveTimeData[1]=Time[2];
		SaveTimeData[2]=Time[1];
		SaveTimeData[3]=Time[0];
		SaveTimeData[0]=ThingType;
	
	}
	else if(Voltage>HighVoltage)
	{
		Count5=0;
		ThingType=1;
		SaveTimeFlag=1;
		SaveTimeData[1]=Time[2];
		SaveTimeData[2]=Time[1];
		SaveTimeData[3]=Time[0];
		SaveTimeData[0]=ThingType;

	}
	if(SaveTimeFlag==1)
	{
		SaveTimeFlag=0;
		WriteEEPROM(SaveDataCount2[Count5],SaveTimeData[Count5]);
		Count5++;
	}
}
void Demand()
{
	bit Only;
	if(KeyFlag9==0&&KeyValue==9)
	{
		KeyFlag9=1;
	}
	if(KeyFlag9==1&&KeyValue==0)
	{
		KeyFlag9=0;
		VoltageFlag=0;
		VoltageCheckFlag=1;
		VoltageThresholdFlag=0;
		DutyCycleFlag=0;
		FrequencyFlag=0;
		BlinkFlag=0;
		Only=1;
		DemandFlag=0;
	}
	if(VoltageCheckFlag==1&&FrequencyFlag==0&&DutyCycleFlag==0)
	{
		if(KeyFlag4==0&&KeyValue==4)
		{
			KeyFlag4=1;
		}
		if(KeyFlag4==1&&KeyValue==0)
		{
			KeyFlag4=0;
			DemandFlag=~DemandFlag;
			Only=1;
		}
		if(Only)
	{
		if(DemandFlag)
	{
		Only=0;
		TemperaryData[0]=ReadEEPROM(0x21);
		TemperaryData[1]=ReadEEPROM(0x22);
		TemperaryData[2]=ReadEEPROM(0x23);
	}
	else
	{
		Only=0;
		TemperarySingleData=ReadEEPROM(0x10);
	}
}
}
}
void MeasureFrequency()
{
	unsigned int X;
	if(KeyFlag5==0&&KeyValue==5)
	{
		KeyFlag5=1;
	}
	if(KeyFlag5==1&&KeyValue==0)
	{
		KeyFlag5=0;
		FrequencyFlag=1;
		VoltageFlag=0;
		VoltageCheckFlag=0;
		VoltageThresholdFlag=0;
		FrequencyCirculFlag=1;
		DutyCycleFlag=0;
		BlinkFlag=0;
		TH0=0;
		TL0=0;
		Time500=1;
	}
	if(Time500)
	{
		TR0=1;
		while(Time500);
		TR0=0;
		X=TH0;
		X=X<<8;
		X|=TL0;
		Count7=X;
		Frequency=X;
		Period=(Million/Frequency);
	}
	if(FrequencyFlag==1&&DutyCycleFlag==0)
	{
		if(KeyValue==4&&KeyFlag4==0)
		{
			KeyFlag4=1;
		}
		if(KeyFlag4==1&&KeyValue==0)
		{
			KeyFlag4=0;
			FrequencyCirculFlag=~FrequencyCirculFlag;
		}
	}
}
void MeasureDutyCycle()
{
	bit Pm;
	if(KeyFlag8==0&&KeyValue==8)
	{
		KeyFlag8=1;
	}
	if(KeyFlag8==1&&KeyValue==0)
	{
		KeyFlag8=0;
		DutyCycleFlag=1;
		FrequencyFlag=0;
		VoltageCheckFlag=0;
		VoltageFlag=0;
		VoltageThresholdFlag=0;
		TH0=0;
		TL0=0;
	}
	if(DutyCycleFlag==1&&Pm==0)
	{
		Pm=1;
		TR0=1;
		if(TL0>0)
			while(GATE);
		TR0=0;
		Count8=TH0;
		Count8<<=8;
		Count8|=TL0;
	}
}