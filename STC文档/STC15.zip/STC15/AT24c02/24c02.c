#include"24c02.h"

void iic_start(void)
{
	SDA = 1;
	_nop_();
   SCL = 1;
   somenop;
   SDA = 0;
   somenop;
   SCL = 0;
}

void iic_stop(void)
{
	SDA = 0;
	_nop_();
	SCL = 1;
	somenop;
	SDA = 1;

}

void iic_ack(bit ackbit)
{
	if(ackbit)
		SDA = 0;
	else
		SDA = 1;
	somenop;
	SCL	 = 1;
	somenop;
	SCL = 0;
	SDA = 1;
	somenop;

}


bit iic_waitack(void)
{
	SDA = 1;
	somenop;
	SCL = 1;
	somenop;
	if(SDA)
	{
		SCL = 0;
		iic_stop();
		return 0;
	}
	else
	{
		SCL = 0;
		return 1;
	}	


}


void iic_sendbyte(uchar bt)
{
	 uchar i;
	 for(i = 0; i<8; i++)
	 {
	 	if(bt&0x80)
		  	SDA = 1;
		else
			SDA = 0;
		somenop;
		SCL = 1;
		bt <<= 1;
		somenop;
		SCL = 0;			
	 }
}


uchar iic_recbyte(void)
{
	uchar da;
	uchar i;
	for(i= 0; i<8; i++)
	{
		SCL = 1;
		somenop;
		da <<= 1;
		if(SDA)
			da |= 0x01;
		 SCL = 0;
		 somenop;
	} 

	return da;
}

void wrbyte_24c02(uchar add, uchar dat)
{
	 iic_start();
	 iic_sendbyte(0xa0);
	 iic_waitack();
	 iic_sendbyte(add);
	 iic_waitack();
	 iic_sendbyte(dat);
	 iic_waitack();
	 iic_stop();
	 delay(10);

}

uchar rdbyte_24c02(uchar add)
{
	 uchar da;
	 iic_start();
	 iic_sendbyte(0xa0);		   //д��ַ
	 iic_waitack();
	 iic_sendbyte(add);
	 iic_waitack();
	 iic_start();
	 iic_sendbyte(0xa1);   //����ַ
	 iic_waitack();
	 da = iic_recbyte();
	 iic_ack(0);
	 iic_stop();
	 return da;


} 

void delay(uchar t)
{
	 uchar i;
	 while(t--)
	 {
	 	for(i = 0; i<112; i++);
	 }
}

