#ifndef _24c02_H_
#define _24c02_H_

#include<reg52.h>
#include<intrins.h>

#define somenop {_nop_();_nop_();_nop_();_nop_();_nop_();}
#define uint unsigned int
#define uchar unsigned char

sbit SCL = P2^0;
sbit SDA = P2^1;

void iic_start(void);
void iic_stop(void);
void iic_ack(bit ackbit);
void iic_sendbyte(uchar bt);
void wrbyte_24c02(uchar add, uchar dat);
void delay(uchar t);

bit iic_waitack(void);
uchar iic_recbyte(void);
uchar rdbyte_24c02(uchar add);


#endif 