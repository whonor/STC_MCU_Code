#include"24c02.h"

uchar dspflag;
uchar cnt;
char tflag;
uchar code dsp_code[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80, 0x90};

void display(uchar d)
{
	if((dspflag ==  0) && (d>99))
	{
		P0 = 0xff;
		P2 &= 0x1f;
		P2 |= 0xe0;
		P0 = dsp_code[d/100]; 
		P2 |= 0xe0;			  
		P2 &= 0x1f;
		P0 = 0x20;
		P2 |= 0xc0;
		P2 &= 0x3f;
		     
	}
	if((dspflag == 1) && (d>9))
	{
		P0 = 0xff;
		P2 |= 0xe0;
		P2 &= 0x1f;
		P0 = dsp_code[d%100/10];
		P2 |= 0xe0;
		P2 &= 0x1f;
		P0 = 0x40;
		P2 |= 0xc0;
		P2 &= 0x3f;
		      
	}
	if(dspflag == 2)
	{
		P0 = 0xff;
		P2 |= 0xe0;
		P2 &= 0x1f;
		P0 = dsp_code[d%100%10];
		P2 |= 0xe0;
		P2 &= 0x1f;
		P0 = 0x80;
		P2 |= 0xc0;
		P2 &= 0x3f;
		      
	}
}

void init_t0(void)
{
	TMOD = 0x02;
	TL0 = 0x06;
	TH0 = 0x06;
	ET0 = 1;
	EA = 1;
	TR0 = 1;

}

void main(void)
{
	cnt = rdbyte_24c02(0x00);
	wrbyte_24c02(0x00, cnt+1);

	init_t0();
	while(1)
	{
		display(cnt);
	}
}

void T0_time() interrupt 1
{
	tflag++;
	if(tflag == 16)
	{
		tflag = 0;
		dspflag++;
		if(dspflag == 3)
			dspflag = 0;

	}
}