#include<reg52.h>
#include<intrins.h>
#define uchar unsigned char
#define Y6C 0xc0
#define Y7C 0xe0
uchar key_value, value;
uchar code table[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
///////////////////////////////////////////////
uchar key_scan(void)
{
	uchar temp;
	P3 = 0xff;
	if(P3 != 0xff)
	{
		_nop_();
		_nop_();
		if(P3 != 0xff)
		{
			temp = P3;

				switch(temp)
				{
					case 0x7e:key_value = 0; break;
					case 0xbe:key_value = 1; break;
					case 0xde:key_value = 2; break;
					case 0xee:key_value = 3; break;
					case 0x7d:key_value = 4; break;
					case 0xbd:key_value = 5; break;
					case 0xdd:key_value = 6; break;
					case 0xed:key_value = 7; break;
					case 0x7b:key_value = 8; break;
					case 0xbb:key_value = 9; break;
					case 0xdb:key_value = 10; break;
					case 0xeb:key_value = 11; break;
					case 0x77:key_value = 12; break;
					case 0xb7:key_value = 13; break;
					case 0xd7:key_value = 14; break;
					case 0xe7:key_value = 15; break;
					default:break;

				}
		}
	}while(P3 != 0xff);
	return key_value;

}
//////////////////////////////////////////////////////////////
void display(uchar v)
{
	if(v < 10)
	{
		P2 &= 0x1f;
		P2 |= Y6C;
		P0 = 0x7f;
		 
	 	P2 &= 0x1f;
		P2 |= Y7C;
		P0 = table[key_value%10];
	}else
	{
		P2 &= 0x1f;
		P2 |= Y6C;
		P0 = 0x7f;
		
		P2 &= 0x1f;
		P2 |= Y7C;
		P0 = table[key_value%10];

		P2 &= 0x1f;
		P2 |= Y6C;
		P0 = 0xbf;
		
		P2 &= 0x1f;
		P2 |= Y7C;
		P0 = table[key_value/10];
		
		  
	}
	 

	  
}
///////////////////////////////////////////////////////////////
void main(void)
{
	P2 &= 0x1f;
	P2 |= 0xa0;
	P0 = 0;
	while(1)
	{
		value = key_scan();
		display(value);
	}
}