#include"reg52.h"
#define uchar unsigned char
#define Y4C 0x80
uchar num;

//////////////////////////////////////////////
void main(void)
{
	TMOD = 0x00;
	TL0 = 65536 - 45872;
	TH0 = (65536 - 45872) >> 8;
	EA = 1; 
	ET0 = 1; 
	TR0 = 1;
	P2 &= 0x1f;
	P2 |= Y4C;
	while(1)
	{
		if(num == 20)
		{
			num = 0;
			P0 = ~P0;
		}
			
	}
}
void T0_time() interrupt 1
{
	   num++;
}

