#ifndef __JIDIANQI_H__
#define __JIDIANQI_H__

sbit RELAY = P1^4;
extern void jidianqi();

#endif